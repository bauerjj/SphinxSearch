#define SPH_SVN_TAG "release"
#define SPH_SVN_REV 3473
#define SPH_SVN_REVSTR "3473"
#define SPH_SVN_TAGREV "r3473"
#define SPHINX_TAG "-release"

#define SPH_SVN_TAG "rel20"
#define SPH_SVN_REV 3308
#define SPH_SVN_REVSTR "3308"
#define SPH_SVN_TAGREV "r3308"
#define SPHINX_TAG "-release"
